
public interface CommandTemplate 
{
	public void doCommand();
	public void undoCommand();
	
}
